#ifndef PARSER_H
#define PARSER_H

typedef struct {
    char name[256];
    char command_line[1024];   
    char stdin_input[1024];
    char expected_output[4096];
    int score;
} Test;

void extract_value(const char *line, char *dest);
void parse_test(char* filename, Test tests[], int *count);

#endif